"""license: Apache License 2.0, see LICENSE for more details."""
BLATHER = 5 # log level for low-level debugging

